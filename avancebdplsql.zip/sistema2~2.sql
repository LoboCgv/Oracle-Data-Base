--select * from banco;    
declare 
cursor bancos is select factura.codbanco,sum(factura.total)totalbanco from banco  join factura on banco.codbanco=factura.codbanco group by(banco.codbanco);
cursor llenado is select codbanco from factura;
begin

for i in llenado loop
update factura set codbanco=3 where codbanco is null;
end loop;
for banco in bancos loop
    dbms_output.put_line(banco.codbanco || banco.totalbanco);
end loop;
end;