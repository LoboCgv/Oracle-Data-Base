--poblar aircraft
declare
km number(5);
begin
  for i in 1..30 loop
    km:=dbms_random.value(5000,45000);--
    insert into aircraft (aid,name,distance) values (i,'aircraft'||to_char(i),km);
  end loop;
end;
