declare
  promedio number(14,5);
  nombre EMPLOYEE.NAME%type;
  salario EMPLOYEE.SALARY%type;
begin
  select avg(salary) into promedio from employee;
  dbms_output.put_line(to_char(promedio));
  --mostrar los nombres de las personas cuyo salario es mayor que el promedio
  for i in 1..2000 loop
    select name,salary into nombre,salario from EMPLOYEE where eid=i;
    if salario>promedio then
      dbms_output.put_line(nombre);  
    end if;
  end loop;
end;
