--select * from AIRCRAFT;AID name distance
--select * from CERTIFICATE;eid aid
select * from employee;eid name salary
--select * from FLIGHT;flno origin destination distance departure_date arrival_date price
declare
  nombreEmpleado EMPLOYEE.EID%type;
  salario EMPLOYEE.SALARY%type;
begin
--bloque for
  for i in 1..31 loop
    select employee.salary
    into salario
    from EMPLOYEE where eid=i;
    DBMS_OUTPUT.PUT_LINE(' Salario '||salario);
  end loop;
end;