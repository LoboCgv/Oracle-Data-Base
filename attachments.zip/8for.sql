--select * from factura;
declare
  rut FACTURA.RUTCLIENTE%type;
  valorNeto FACTURA.NETO%type;
begin
  for i in 11520..11528 loop
    select rutcliente,neto 
    into rut,valorNeto
    from factura
    where NUMFACTURA=i;
    DBMS_OUTPUT.PUT_line(rut||' '||to_char(valorNeto,'999,999,999.000'));
    
  end loop;
end;