-- Estructuras de control ciclos
--loop bucle infinito hasta que se le diga cuando saldra
--for usaremos for por un asunto de manejo recursos
--while
--manejo de tablas de multiplicar
declare
  numeroActual number(2):=5;
  resultado number(3);
begin
  for i in 1..10 loop
    resultado:=numeroActual*i;
    dbms_output.put_line('5X'||to_char(i)||'='||to_char(resultado));
  end loop;
end;