set serveroutput on format wrapped;-- iniciar bloque anonimo
DECLARE	--inicio de decklacion de variables
--declare s opcional
--pueden ponerse todos los bloques de declaracion que quiera
	nombre VARCHAR2(20);
	numero NUMBER(7,2):=50;
	fecha date;
BEGIN--inicio del procedimiento
--se necesita tener instrucciones entre begin y end
  nombre:='Carlos';
	dbms_output.put_line('Hola'||nombre);--saldia por consola y || es para concatenar
	dbms_output.put_line('numero: '|| to_char(numero));--to_char trabaja para convertir
  fecha:=sysdate+7;-- sysdate obtiene la fecha de hoy
  dbms_output.put_line('fecha de hoy'||to_char(sysdate)|| 'en una semana sera'||to_char(fecha));
  declare
  flag boolean:=false;-- esta variable es visible dentro de su bloque las anteriores se pueden usar
  -- por transitividad
  begin
  --se puede poner null para que no arroje error
  fecha:=fecha+7;--aumento en dos semanas la fecha de hoy
  if flag then
    dbms_output.put_line(to_char(fecha));
  else
    dbms_output.put_line('EL valor es false');
  end if;
  
  end;
  
end;