--si prob es mayor que 80% entonces se agrega la certificacion
--caso contrario no se agrega
declare 
prob number(3);
begin
  for i in 1..10 loop
    for j in 1..30 loop
      prob:=dbms_random.value(1,99);
      if prob>80 then
        insert into certificate (eid,aid) values (i,j);
      end if;
    end loop;
  end loop;
end;