declare
  nombreCliente cliente.nombre%type;
  direccionCliente cliente.direccion%type;
  creditoCliente cliente.credito%type;
  --contador
  i number(2):=0;
  --hay nueve filas en la bd
begin
  loop
    i:=i+1;
    select nombre,direccion,credito
    into nombreCliente,direccionCliente,creditoCliente
    from cliente
    where codcomuna=1;
    dbms_output.put_line(nombreCliente||to_char(creditoCliente));
    if i=4 then
      exit;
    end if;
  --sentencia select
  end loop;
end;