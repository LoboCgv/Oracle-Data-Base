--insertar elementos en la tabla employee
--agrego 10 registros
declare
 salario number(9,0):=0;
begin
  for i in 1..10 loop
    salario:=dbms_random.value(500000,1999999);
    insert into employee (eid,NAME,salary) values (i,'Emp'||to_char(i),salario);
  end loop;
end;
